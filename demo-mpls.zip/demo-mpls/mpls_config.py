mpls_configs = {
    'R1': [
        'int f0/0',
        'mpls ip',
        'int f1/0',
        'mpls ip',
        'int f2/0',
        'mpls ip',
        'exit',
    ],
    'R2': [
        'int f0/0',
        'mpls ip',
        'int f1/0',
        'mpls ip',
        'exit',
    ],
    'R3': [
        'int f0/0',
        'mpls ip',
        'int f1/0',
        'mpls ip',
        'int f2/0',
        'mpls ip',
        'exit',
    ],
    'R4': [
        'int f0/0',
        'mpls ip',
        'int f1/0',
        'mpls ip',
        'exit',
    ],
    'PE-1': [
        'int f2/0',
        'mpls ip',
        'exit',
    ],
    'PE-2': [
        'int f2/0',
        'mpls ip',
        'exit',
    ],
}